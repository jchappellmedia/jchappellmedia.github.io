#!/usr/bin/env python3
"""
sd_video_recover.py — recover deleted or formatted-over camera video from an SD card.

Built for Sony cameras (XAVC S / XAVC HS .MP4 files), and also works for most
other cameras that write MP4/MOV files to exFAT cards (Canon, Panasonic, Fuji,
GoPro, DJI, phones...).

How it works
------------
Deleting a clip or quick-formatting a card only erases the *list* of files.
The video itself stays on the card until something new is recorded over it.
This tool reads the card's raw storage, finds every place where a video file
begins, rebuilds each clip, and tells you whether it's still intact.

It is strictly READ-ONLY on the card. It never writes to the card.

Usage (macOS or Linux, needs Python 3.8+, no extra packages)
-----------------------------------------------------------
  1. List cards:        sudo python3 sd_video_recover.py disks
  2. Find lost clips:   sudo python3 sd_video_recover.py scan /dev/rdisk4s1
  3. Recover by ID:     sudo python3 sd_video_recover.py recover /dev/rdisk4s1 184135 --out ~/Desktop/Recovered

See README.md for the full walkthrough.
License: MIT.
"""
import argparse
import os
import platform
import shutil
import struct
import subprocess
import sys
import time

VERSION = "1.0"
ALIGN = 4096            # raw devices want aligned reads
EPOCH_1904 = 2082844800  # MP4 timestamps count from 1904
KNOWN_ATOMS = {b"ftyp", b"uuid", b"free", b"skip", b"wide", b"mdat", b"moov",
               b"meta", b"udta", b"pnot", b"PICT", b"XMP_"}


# ─────────────────────────────── raw device ────────────────────────────────

class Device:
    """Read-only, alignment-safe reader for a raw disk, partition or image file."""

    def __init__(self, path):
        self.path = path
        self.f = open(path, "rb", buffering=0)
        self.base = 0

    def read(self, off, n):
        off += self.base
        start = off - off % ALIGN
        end = off + n
        end += (-end) % ALIGN
        self.f.seek(start)
        buf = bytearray()
        while len(buf) < end - start:
            chunk = self.f.read(min(end - start - len(buf), 64 << 20))
            if not chunk:
                break
            buf += chunk
        return bytes(buf[off - start: off - start + n])


def find_exfat(dev):
    """Accept a partition, or a whole disk with an MBR/GPT; locate the exFAT volume."""
    if dev.read(0, 512)[3:11] == b"EXFAT   ":
        return
    mbr = dev.read(0, 512)
    starts = []
    if mbr[510:512] == b"\x55\xaa":
        for i in range(4):
            e = mbr[446 + 16 * i: 462 + 16 * i]
            lba, = struct.unpack_from("<I", e, 8)
            if e[4] == 0xEE:  # protective MBR -> GPT
                hdr = dev.read(512, 512)
                if hdr[:8] == b"EFI PART":
                    ent_lba, n, sz = struct.unpack_from("<QII", hdr, 72)
                    tbl = dev.read(ent_lba * 512, n * sz)
                    for j in range(n):
                        first, = struct.unpack_from("<Q", tbl, j * sz + 32)
                        if first:
                            starts.append(first * 512)
            elif lba:
                starts.append(lba * 512)
    for s in starts:
        if dev.read(s, 512)[3:11] == b"EXFAT   ":
            dev.base = s
            return
    sys.exit("No exFAT file system found on %s.\n"
             "Cards 32 GB and smaller are often FAT32, which this tool doesn't support yet." % dev.path)


# ──────────────────────────────── exFAT ────────────────────────────────────

class ExFat:
    def __init__(self, dev):
        find_exfat(dev)
        self.dev = dev
        bs = dev.read(0, 512)
        self.bps = 1 << bs[0x6C]
        self.cs = self.bps << bs[0x6D]
        fat_off, _, heap_off, self.ncl, root = struct.unpack_from("<IIIII", bs, 0x50)
        self.heap = heap_off * self.bps
        self.fat = dev.read(fat_off * self.bps, (self.ncl + 2) * 4)
        self.bitmap = self._load_bitmap(root)

    def coff(self, c):
        return self.heap + (c - 2) * self.cs

    def chain(self, c):
        out = []
        while 2 <= c < self.ncl + 2 and len(out) <= self.ncl:
            out.append(c)
            c, = struct.unpack_from("<I", self.fat, c * 4)
        return out

    def _load_bitmap(self, root):
        data = b"".join(self.dev.read(self.coff(c), self.cs) for c in self.chain(root))
        for i in range(0, len(data), 32):
            if data[i] == 0x81:
                fc, = struct.unpack_from("<I", data, i + 0x14)
                ln, = struct.unpack_from("<Q", data, i + 0x18)
                return self.dev.read(self.coff(fc), ln)
        sys.exit("Couldn't find the exFAT allocation bitmap — is this card damaged?")

    def in_use(self, c):
        b = c - 2
        return bool(self.bitmap[b >> 3] >> (b & 7) & 1)

    def used_in(self, first, count):
        return sum(self.in_use(c) for c in range(first, first + count)
                   if 2 <= c < self.ncl + 2)


# ─────────────────────────────── MP4 parsing ───────────────────────────────

def atom_at(read, off):
    h = read(off, 16)
    if len(h) < 8:
        return None, 0
    size, kind = struct.unpack(">I4s", h[:8])
    if size == 1:
        size, = struct.unpack(">Q", h[8:16])
    return kind, size


def mvhd_info(moov):
    i = moov.find(b"mvhd")
    if i < 0:
        return {}
    if moov[i + 4] == 1:
        ct, _, scale, dur = struct.unpack_from(">QQIQ", moov, i + 8)
    else:
        ct, _, scale, dur = struct.unpack_from(">IIII", moov, i + 8)
    return {"created": ct - EPOCH_1904 if ct > EPOCH_1904 else None,
            "duration": dur / scale if scale else None}


class Clip:
    """One video found in free space. `pieces` is [(device_offset, length), ...]."""

    def __init__(self, cid, layout, pieces, size, meta, used):
        self.id, self.layout, self.pieces, self.size = cid, layout, pieces, size
        self.created, self.duration = meta.get("created"), meta.get("duration")
        self.used = used          # clusters now claimed by live files
        self.overlaps = []        # other found clips sharing space

    def span(self, fs):
        return [((o - fs.heap) // fs.cs + 2, -(-n // fs.cs)) for o, n in self.pieces]


def walk_atoms(read, off, stop_at):
    """Walk top-level atoms starting at `off`; return (end_offset, moov_bytes)."""
    moov = None
    while True:
        kind, size = atom_at(read, off)
        if kind not in KNOWN_ATOMS or size < 8:
            return off, moov
        if kind == b"moov":
            moov = read(off, min(size, 64 << 20))
        off += size
        if off > stop_at:
            return None, None


def try_layouts(fs, c):
    """Given a cluster that begins with 'ftyp', work out where the rest of the file lives."""
    dev = fs.dev
    base = fs.coff(c)
    head = dev.read(base, max(fs.cs, 1 << 20))
    # find mdat in the header region
    off, mdat_off, mdat_size = 0, None, None
    while off < len(head) - 16:
        kind, size = atom_at(lambda o, n: head[o:o + n], off)
        if kind not in KNOWN_ATOMS or size < 8:
            break
        if kind == b"mdat":
            mdat_off, mdat_size = off, size
            break
        off += size
    limit = (fs.ncl + 2 - c) * fs.cs

    # Layout A: whole file in one continuous block (most cameras, phones, fast-start files)
    rd = lambda o, n: dev.read(base + o, n)
    end, moov = walk_atoms(rd, 0, limit)
    if end and moov:
        return Clip(c, "continuous", [(base, end)], end, mvhd_info(moov),
                    fs.used_in(c, -(-end // fs.cs)))

    # Layout B (Sony XAVC): header cluster(s) sit right AFTER the data run.
    if mdat_off is None or mdat_size in (0, 8, 16):
        return None
    hdr_len = -(-(mdat_off + 16) // fs.cs) * fs.cs
    moov_off = mdat_off + mdat_size
    k = (moov_off - hdr_len) // fs.cs
    for n_data in range(k + 1, k + 12):
        d0 = c - n_data
        if d0 < 2:
            break
        dbase = fs.coff(d0) - hdr_len
        rd = lambda o, n, dbase=dbase: dev.read(dbase + o, n)
        kind, _ = atom_at(rd, moov_off)
        if kind != b"moov":
            continue
        end, moov = walk_atoms(rd, moov_off, limit + c * fs.cs)
        if not end or not moov:
            continue
        if -(-(end - hdr_len) // fs.cs) != n_data:
            continue
        pieces = [(base, hdr_len), (fs.coff(d0), end - hdr_len)]
        used = fs.used_in(c, hdr_len // fs.cs) + fs.used_in(d0, n_data)
        return Clip(c, "sony", pieces, end, mvhd_info(moov), used)
    return None


# ──────────────────────────────── commands ─────────────────────────────────

def fmt_time(t):
    return time.strftime("%Y-%m-%d %H:%M", time.localtime(t)) if t else "unknown"


def fmt_dur(s):
    if s is None:
        return "?"
    s = int(round(s))
    return "%d:%02d:%02d" % (s // 3600, s % 3600 // 60, s % 60) if s >= 3600 else "%d:%02d" % (s // 60, s % 60)


def open_card(path):
    try:
        dev = Device(path)
    except PermissionError:
        sys.exit("Permission denied reading %s — run with sudo." % path)
    except FileNotFoundError:
        sys.exit("No such device: %s  (run the 'disks' command to list cards)" % path)
    return ExFat(dev)


def scan_clips(fs, only=None):
    free = [c for c in (only or range(2, fs.ncl + 2)) if only or not fs.in_use(c)]
    clips, t0 = [], time.time()
    for n, c in enumerate(free):
        if not only and n % 5000 == 0:
            pct = n / max(len(free), 1)
            eta = (time.time() - t0) / pct * (1 - pct) if pct > 0.02 else 0
            print("\r  scanning free space... %5.1f%%  %s" % (
                100 * pct, "(~%d min left)" % (eta // 60 + 1) if eta else ""), end="", flush=True)
        if fs.dev.read(fs.coff(c), 16)[4:8] != b"ftyp":
            continue
        clip = try_layouts(fs, c)
        if clip:
            clips.append(clip)
    if not only:
        print("\r  scanning free space... 100.0%" + " " * 20)
    # clips that share clusters: the older one was recorded over
    spans = {cl.id: [(a, a + n) for a, n in cl.span(fs)] for cl in clips}
    for a in clips:
        for b in clips:
            if a is not b and any(x0 < y1 and y0 < x1 for x0, x1 in spans[a.id] for y0, y1 in spans[b.id]):
                a.overlaps.append(b)
    return clips


def status(clip):
    newer = [o for o in clip.overlaps if (o.created or 0) > (clip.created or 0)]
    if clip.used:
        return "DAMAGED (partly recorded over by a current file)"
    if newer:
        return "DAMAGED (recorded over by clip %d)" % newer[0].id
    return "INTACT"


def cmd_disks(_):
    if platform.system() == "Darwin":
        subprocess.call(["diskutil", "list", "external", "physical"])
        print("\nUse the partition with 'r' added, e.g. disk4s1 -> /dev/rdisk4s1 (faster).")
        print("Unmount it first (don't eject):  diskutil unmount /dev/disk4s1")
    else:
        subprocess.call(["lsblk", "-o", "NAME,SIZE,FSTYPE,LABEL,MOUNTPOINT"])
        print("\nUse the partition, e.g. /dev/sdb1 or /dev/mmcblk0p1. Unmount it first: sudo umount /dev/sdb1")


def cmd_scan(a):
    fs = open_card(a.device)
    free = sum(not fs.in_use(c) for c in range(2, fs.ncl + 2))
    print("Card: %.1f GB exFAT, %d KB clusters, %.1f GB free to search" % (
        fs.ncl * fs.cs / 1e9, fs.cs // 1024, free * fs.cs / 1e9))
    clips = scan_clips(fs)
    if not clips:
        print("\nNo recoverable video found in free space.")
        return
    clips.sort(key=lambda c: c.created or 0, reverse=True)
    print("\nFound %d clip(s), newest first:\n" % len(clips))
    print("  %-9s %-17s %9s %9s  %-10s %s" % ("ID", "RECORDED", "LENGTH", "SIZE", "LAYOUT", "STATUS"))
    for c in clips:
        print("  %-9d %-17s %9s %7.2f GB  %-10s %s" % (
            c.id, fmt_time(c.created), fmt_dur(c.duration), c.size / 1e9, c.layout, status(c)))
    print("\nRecover with:\n  sudo python3 %s recover %s <ID> [<ID> ...] --out <folder on another drive>"
          % (os.path.basename(sys.argv[0]), a.device))


def same_device(out, device):
    try:
        return os.stat(out).st_dev == os.stat(device).st_rdev
    except OSError:
        return False


def give_back(path):
    uid, gid = os.environ.get("SUDO_UID"), os.environ.get("SUDO_GID")
    if uid:
        os.chown(path, int(uid), int(gid))


def cmd_recover(a):
    fs = open_card(a.device)
    out = os.path.abspath(os.path.expanduser(a.out))
    os.makedirs(out, exist_ok=True)
    give_back(out)
    if same_device(out, a.device):
        sys.exit("Refusing: the output folder is on the card you're recovering from. Pick another drive.")
    clips = scan_clips(fs, only=[int(i) for i in a.ids])
    found = {c.id: c for c in clips}
    for cid in map(int, a.ids):
        c = found.get(cid)
        if not c:
            print("ID %d: no recoverable clip starts there (was it from a 'scan' of this card?)" % cid)
            continue
        free = shutil.disk_usage(out).free
        if c.size > free - (1 << 30):
            print("ID %d: needs %.1f GB but only %.1f GB free in %s — skipping." % (cid, c.size / 1e9, free / 1e9, out))
            continue
        name = "recovered_%s_%d.MP4" % (time.strftime("%Y-%m-%d_%H%M%S", time.localtime(c.created))
                                        if c.created else "unknown", cid)
        path = os.path.join(out, name)
        print("ID %d  %s  %s  %.2f GB  [%s]\n  -> %s" % (cid, fmt_time(c.created), fmt_dur(c.duration),
                                                        c.size / 1e9, status(c), path))
        done, t0 = 0, time.time()
        with open(path, "wb") as f:
            for off, n in c.pieces:
                pos = 0
                while pos < n:
                    step = min(32 << 20, n - pos)
                    f.write(fs.dev.read(off + pos, step))
                    pos += step
                    done += step
                    mbps = done / 1e6 / max(time.time() - t0, 0.001)
                    print("\r  %5.1f%%  %4.0f MB/s" % (100 * done / c.size, mbps), end="", flush=True)
        give_back(path)
        print()
        if shutil.which("ffprobe"):
            r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                                "-of", "csv=p=0", path], capture_output=True, text=True)
            print("  verified: plays, %s long" % fmt_dur(float(r.stdout.strip()))
                  if r.returncode == 0 and r.stdout.strip() else "  warning: ffprobe couldn't read it:\n  " + r.stderr.strip())
        print("  done")


def main():
    p = argparse.ArgumentParser(description="Recover deleted/formatted camera video from an exFAT SD card (read-only).")
    p.add_argument("--version", action="version", version=VERSION)
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("disks", help="list connected cards")
    s = sub.add_parser("scan", help="find recoverable clips")
    s.add_argument("device", help="e.g. /dev/rdisk4s1 (macOS) or /dev/sdb1 (Linux), or an image file")
    r = sub.add_parser("recover", help="recover clips by ID")
    r.add_argument("device")
    r.add_argument("ids", nargs="+", help="clip IDs from 'scan'")
    r.add_argument("--out", required=True, help="folder to save into (NOT on the card)")
    a = p.parse_args()
    {"disks": cmd_disks, "scan": cmd_scan, "recover": cmd_recover}[a.cmd](a)


if __name__ == "__main__":
    main()
