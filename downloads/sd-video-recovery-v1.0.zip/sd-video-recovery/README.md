# SD Card Video Recovery

Get back camera clips you deleted or formatted off an SD card. It's free, it's a single file, and it's **read-only**, so it never writes to your card.

It was built for Sony cameras (XAVC S / XAVC HS `.MP4` files, e.g. FX3, FX30, A7 IV, A7S III, ZV-E1) and also works for most cameras that record MP4/MOV to exFAT cards (Canon, Panasonic, Fujifilm, GoPro, DJI, phones).

> **Real-world result:** it recovered a 31-minute, 24 GB 4K clip from a card that had been formatted *and* re-recorded on. The clip came back intact and plays start to finish.

---

## ⚠️ Stop using the card first

When you delete a clip or quick-format a card, only the card's list of files is erased. The video itself stays on the card **until something new is recorded over it.** So right now:

- **Don't** record anything else on the card.
- **Don't** format it again.
- **Don't** open it in Finder or Explorer more than you have to. Your computer quietly writes files to any card it mounts.

---

## What you need

- A **Mac** or **Linux** computer. Windows isn't supported yet.
- **Python 3.** Most Macs have it. Type `python3 --version` in Terminal, and if it offers to install developer tools, click Install.
- **Free space somewhere other than the card**, at least as much as the clip. A 30-minute 4K clip is about 25 GB.
- Optional: **ffmpeg**, which lets the tool confirm each recovered file actually plays (`brew install ffmpeg`).

---

## Step by step (Mac)

Open **Terminal** (Applications → Utilities → Terminal), then `cd` into the folder that contains `sd_video_recover.py`.

**1. Find your card.**

```bash
sudo python3 sd_video_recover.py disks
```

You'll be asked for your Mac password. Nothing appears on screen as you type; that's normal. Look for your card by size, for example `disk4` with a partition `disk4s1`.

**2. Unmount the card (don't eject it).** This stops macOS from writing to it.

```bash
diskutil unmount /dev/disk4s1
```

**3. Scan for lost clips.** Use `rdisk` (with an **r**) because it's much faster. This takes a few minutes on a big card.

```bash
sudo python3 sd_video_recover.py scan /dev/rdisk4s1
```

You'll get a table like this:

```
  ID        RECORDED             LENGTH      SIZE  LAYOUT     STATUS
  184135    2026-09-25 20:57      31:24  24.09 GB  sony       INTACT
  189255    2026-09-16 21:13      32:18  24.76 GB  sony       DAMAGED (recorded over by clip 184135)
  908265    2026-09-23 21:22      17:24  13.36 GB  sony       INTACT
```

Find your clip by **date and length**. The camera's filename (like `C9790.MP4`) isn't stored inside the video, so the table can't show it.

**4. Recover it.** Put the ID(s) after `recover`, and save to your Mac or an external drive, **never the same card**.

```bash
sudo python3 sd_video_recover.py recover /dev/rdisk4s1 184135 --out ~/Desktop/Recovered
```

You can recover several clips at once: `recover /dev/rdisk4s1 184135 908265 --out ...`

When it finishes, the files are in the folder you chose, named by recording date.

## Linux

The steps are the same. Use `lsblk` (or the `disks` command) to find the partition, such as `/dev/sdb1` or `/dev/mmcblk0p1`, unmount it with `sudo umount /dev/sdb1`, then run `scan` and `recover` on that path.

---

## Reading the results

| Status | Meaning |
|---|---|
| **INTACT** | Every part of the clip is still on the card. It should recover perfectly. |
| **DAMAGED (recorded over by clip X)** | A newer clip was recorded on top of part of this one. Recovering it may give you a file that's partly broken or won't open. |
| **DAMAGED (partly recorded over by a current file)** | A clip that's still on the card now occupies part of this one's space. |

- **Times** are shown in your computer's time zone.
- **LAYOUT** is how the camera arranged the file on the card: `sony` (header stored after the video) or `continuous`. It's informational only.
- **ID** is just where the clip starts on the card. Copy it exactly.

---

## FAQ

**I formatted the card in the camera. Can this still work?**
Usually, yes. A normal in-camera format is a "quick" format that leaves the video in place. If you used Sony's *Full Format* / *Low-level format*, or a "secure erase," the data has been wiped and can't be recovered.

**I recorded more after formatting. Is my clip gone?**
Maybe not. New recordings usually go at the start of the card, so older clips further in often survive. Run a scan and see what's marked INTACT.

**It says "No exFAT file system found."**
Cards 32 GB and smaller often use FAT32, which isn't supported yet. Also check that you gave it the right disk.

**It says "Permission denied."**
Put `sudo` at the start of the command.

**It found nothing.**
The clip was either recorded over, or its first few kilobytes were overwritten (for example by your computer after mounting the card). The tool needs the start of the file to find it. If the video is really valuable, stop here and talk to a professional recovery service.

**Is it safe?**
It opens the card read-only, and it refuses to save output onto the card it's reading. The code is one readable Python file with no downloads or dependencies.

---

## How it works (for the curious)

exFAT cards keep a list of files plus a map of which space is in use. Deleting or formatting clears both, but leaves the video bytes alone. This tool:

1. Reads the card's map to find space that's currently marked **free**.
2. Checks the start of each free block for an MP4/MOV signature (`ftyp`).
3. Rebuilds each file by following its structure (`mdat` = video, `moov` = index). Sony cameras write a 128 KB header *after* the video data rather than before it, and the tool handles that layout automatically.
4. Reads the recording date and length from the file's own index, and checks whether any of its space has since been reused.
5. Copies the pieces, in order, to a new file on another drive.

## License

MIT. Free to use, share, and modify.
