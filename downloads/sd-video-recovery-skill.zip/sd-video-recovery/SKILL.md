---
name: sd-video-recovery
description: Recover deleted or formatted-over video clips (MP4/MOV) from a camera SD card or memory card, read-only. Built for Sony XAVC cameras (FX3, FX30, A7 IV, A7S III, ZV-E1...) and works for most cameras that record to exFAT cards (Canon, Panasonic, Fujifilm, GoPro, DJI). Use whenever the user says they deleted, lost, erased, or formatted a clip, wants to recover/undelete/restore footage from an SD card, or asks whether a lost video can be brought back. macOS and Linux.
---

# SD card video recovery

Deleting a clip or quick-formatting a card erases only the file list. The
video bytes stay on the card until something new is recorded over them.
`scripts/sd_video_recover.py` (in this skill's folder) reads the raw card,
finds every video that still starts in free space, rebuilds it — including
Sony's layout, where the 128 KB header is stored *after* the video data — and
reports whether each one is intact. It is read-only on the card.

## Ground rules — never break these

- **Never write to the card.** No formatting, no copying files onto it, no
  saving recovered clips to it. The script refuses to, but don't try.
- **Unmount, don't eject**, before scanning, so the OS stops writing to it
  (macOS writes Spotlight and `.fseventsd` files to any mounted card, and those
  land in exactly the free space where the lost clip lives).
- **You can't type the user's password.** Every command that touches the raw
  device needs `sudo`. Give the user the exact command to run in their own
  terminal, or, if you have a tool that types into the user's terminal, use it
  and ask them to enter their password there. Then read the output.
- Recovered clips need free space **somewhere other than the card**, at least
  the clip size plus 1 GB. Check before recovering.

## Workflow

### 1. Understand what was lost
Ask (briefly) for anything that helps identify the clip: roughly when it was
recorded, how long it was, the camera, and the filename if they know it (for
example `C9790.MP4`). The filename is **not** stored inside the video, so date
and length are what you'll match on.

### 2. Find the card and see what's still on it
macOS:
```bash
diskutil list external physical
```
Linux: `lsblk -o NAME,SIZE,FSTYPE,LABEL,MOUNTPOINT`

If more than one external disk shows up, confirm with the user which one is
the card. If it's mounted, glance at the surviving clips (Sony:
`PRIVATE/M4ROOT/CLIP/`) with `ls -la` and, if `ffprobe` exists, the
`creation_time` of the earliest surviving clip. Camera clip numbers are
sequential, so a lost `C9790` was recorded just before `C9791` started. That
gives you a "recorded before" time to match against.

Then unmount it (macOS: `diskutil unmount /dev/diskNsM`; Linux:
`sudo umount /dev/sdX1`). Use the raw device for speed on macOS:
`/dev/rdiskNsM`.

### 3. Scan (user runs it, with sudo)
```bash
sudo python3 "<skill folder>/scripts/sd_video_recover.py" scan /dev/rdiskNsM
```
It takes a few minutes on a large card and prints a table: `ID`, `RECORDED`
(local time), `LENGTH`, `SIZE`, `LAYOUT`, `STATUS`.

Read the table with the user:
- Match the clip by date and length. When the user gave a filename, the right
  one is usually the newest clip recorded before the next-numbered surviving
  clip.
- `INTACT`: everything is still there.
- `DAMAGED (recorded over by clip X)`: a newer recording overlaps it. Say so
  honestly; recovering it may give a partly broken file.
- If nothing matches, check with the user whether this is the right card. A
  scan finding nothing usually means the clip's start was overwritten.

### 4. Check space, then recover
```bash
df -h ~
```
If the Mac doesn't have clip size + 1 GB free, ask the user to free space or
plug in an external drive, and use that as `--out`. Then have them run:
```bash
sudo python3 "<skill folder>/scripts/sd_video_recover.py" recover /dev/rdiskNsM <ID> --out ~/Desktop/Recovered
```
Several IDs can go in one command. Files are named `recovered_<date>_<ID>.MP4`.

### 5. Prove it's the right clip
- If `ffprobe` is available, confirm the duration matches.
- Pull a frame from the middle and look at it with the user:
  `ffmpeg -v error -ss <mid-seconds> -i <file> -frames:v 1 -vf scale=640:-1 /tmp/check.jpg`,
  then read the image. If the user shared a screenshot of the lost clip,
  compare the two.
- Decode the last ~20 seconds to check the file isn't truncated:
  `ffmpeg -v error -sseof -20 -i <file> -f null -` (no output = clean).
- Rename it to the original filename if the user wants.

Only after the user has their clip safely copied and verified should they
reformat or reuse the card.

## Troubleshooting

| Symptom | Fix |
|---|---|
| `Permission denied` | The command needs `sudo`. |
| `No exFAT file system found` | Wrong disk, or a FAT32 card (usually 32 GB and under), which isn't supported. |
| `Resource busy` / card remounted | macOS remounts cards when replugged. Unmount again. |
| Mac doesn't have enough free space | Use an external drive for `--out`. Never the card. |
| The clip isn't in the list | Its first cluster was overwritten. This tool can't rebuild it; suggest a professional recovery service if it's irreplaceable. |
| Windows | Not supported. Use a Mac or Linux machine. |

The script needs Python 3.8+ and nothing else; `ffmpeg`/`ffprobe` are optional
and only used for verification.
