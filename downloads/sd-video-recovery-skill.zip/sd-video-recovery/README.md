# SD Card Video Recovery: a Claude skill

Deleted a clip or formatted your card too soon? Install this skill, plug in the card, and ask Claude to get your footage back. Claude finds every lost clip, tells you which ones are still intact, recovers the one you want, and checks that it plays.

It's read-only, so it never writes to your card. It works on a Mac or Linux computer, with Sony cameras and most others that record MP4/MOV.

## You'll need

- **Claude Code**, either in the Claude desktop app (the **Code** tab) or in Terminal.
  Regular Claude chat can't reach your SD card, so the skill has to run in Claude Code.
- A Mac or Linux computer, and your Mac password (Claude will ask you to type it once or twice).
- Free space on your computer or an external drive, at least as big as the clip. A 30-minute 4K clip is about 25 GB.

## Install (1 minute)

1. Unzip the download. You'll get a folder called `sd-video-recovery`.
2. Move that folder into your Claude skills folder:
   - **Mac:** in Finder, press **⌘⇧G**, paste `~/.claude/skills`, and press Return. (If it says the folder doesn't exist, create a folder called `skills` inside `~/.claude`.) Drag `sd-video-recovery` in.
   - **Or in Terminal:**
     ```bash
     mkdir -p ~/.claude/skills && mv ~/Downloads/sd-video-recovery ~/.claude/skills/
     ```
3. Start a new Claude Code session. That's it.

## Use it

1. **Stop using the card.** Don't record on it or format it.
2. Plug it into your computer.
3. Tell Claude something like:
   > I deleted a clip from my SD card. It was about 30 minutes long, recorded last week. Can you get it back?

Claude takes it from there. When it asks, type your password in the terminal (the characters won't show up as you type; that's normal).

## Good to know

- It can't bring back clips that were fully recorded over, or cards wiped with a *full* or *low-level* format.
- Cards 32 GB and under that use FAT32 aren't supported yet.
- Windows isn't supported yet.

Made by [Josh Chappell](https://jchappellmedia.github.io). MIT licensed, so share it freely.
